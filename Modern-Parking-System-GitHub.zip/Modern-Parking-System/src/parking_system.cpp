#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <ctime>
#include <algorithm>

using namespace std;

/*
    MODERN PARKING SYSTEM
    Data Structures and Algorithms - Task One

    Modules:
    1. Display parking slot availability
    2. Record vehicle arrival
    3. Assign an available parking slot
    4. Calculate parking duration
    5. Calculate parking fees
    6. Process vehicle exit and payment
    7. Open the exit barrier after successful payment

    Data structures:
    - vector: stores parking slots and active vehicles
    - struct: groups related vehicle and slot information
*/

struct ParkingSlot {
    int slotNumber;
    bool occupied;
    string vehicleRegistration;
};

struct Vehicle {
    string registrationNumber;
    int slotNumber;
    time_t arrivalTime;
};

class ParkingSystem {
private:
    vector<ParkingSlot> parkingSlots;
    vector<Vehicle> parkedVehicles;

public:
    ParkingSystem(int numberOfSlots) {
        for (int i = 1; i <= numberOfSlots; ++i) {
            parkingSlots.push_back({i, false, ""});
        }
    }

    // Display all parking slots and their current status.
    void displayParkingSlots() const {
        cout << "\n=========================================\n";
        cout << "       PARKING SLOT AVAILABILITY\n";
        cout << "=========================================\n";

        for (const auto& slot : parkingSlots) {
            cout << "Slot " << setw(2) << slot.slotNumber << " : ";
            if (slot.occupied) {
                cout << "OCCUPIED (" << slot.vehicleRegistration << ")";
            } else {
                cout << "AVAILABLE";
            }
            cout << '\n';
        }
        cout << "=========================================\n";
    }

    // Find the first available slot.
    int findAvailableSlot() const {
        for (const auto& slot : parkingSlots) {
            if (!slot.occupied) {
                return slot.slotNumber;
            }
        }
        return -1;
    }

    // Register a vehicle and assign it an available slot.
    void vehicleArrival() {
        string registrationNumber;

        cout << "\n=========================================\n";
        cout << "          VEHICLE ARRIVAL\n";
        cout << "=========================================\n";
        cout << "Enter vehicle registration number: ";
        cin >> registrationNumber;

        // Prevent the same vehicle from being registered twice.
        for (const auto& vehicle : parkedVehicles) {
            if (vehicle.registrationNumber == registrationNumber) {
                cout << "\nThis vehicle is already parked.\n";
                return;
            }
        }

        int slotNumber = findAvailableSlot();

        if (slotNumber == -1) {
            cout << "\nSorry, the parking area is FULL.\n";
            return;
        }

        time_t arrivalTime = time(nullptr);

        parkedVehicles.push_back({
            registrationNumber,
            slotNumber,
            arrivalTime
        });

        parkingSlots[slotNumber - 1].occupied = true;
        parkingSlots[slotNumber - 1].vehicleRegistration =
            registrationNumber;

        cout << "\nVehicle successfully registered.\n";
        cout << "Vehicle Registration : " << registrationNumber << '\n';
        cout << "Assigned Slot        : " << slotNumber << '\n';
        cout << "Arrival Time         : " << ctime(&arrivalTime);
        cout << "Barrier: OPEN\n";
        cout << "Please proceed to your assigned parking slot.\n";
    }

    // Calculate the fee using the rates in the assignment.
    double calculateFee(long long minutes) const {
        if (minutes <= 30) {
            return 0.00;
        } else if (minutes <= 120) {
            return 50.00;
        } else if (minutes <= 240) {
            return 100.00;
        } else if (minutes <= 360) {
            return 300.00;
        } else {
            return 500.00;
        }
    }

    // Process vehicle exit, payment and barrier opening.
    void vehicleExit() {
        string registrationNumber;

        cout << "\n=========================================\n";
        cout << "            VEHICLE EXIT\n";
        cout << "=========================================\n";
        cout << "Enter vehicle registration number: ";
        cin >> registrationNumber;

        auto vehicle = find_if(
            parkedVehicles.begin(),
            parkedVehicles.end(),
            [&](const Vehicle& v) {
                return v.registrationNumber == registrationNumber;
            }
        );

        if (vehicle == parkedVehicles.end()) {
            cout << "\nVehicle not found in the parking area.\n";
            return;
        }

        time_t exitTime = time(nullptr);
        long long secondsParked =
            static_cast<long long>(difftime(exitTime, vehicle->arrivalTime));
        long long minutesParked = secondsParked / 60;

        long long hours = minutesParked / 60;
        long long minutes = minutesParked % 60;
        double fee = calculateFee(minutesParked);

        cout << "\n-----------------------------------------\n";
        cout << "           PARKING RECEIPT\n";
        cout << "-----------------------------------------\n";
        cout << "Vehicle Registration : "
             << vehicle->registrationNumber << '\n';
        cout << "Parking Slot         : "
             << vehicle->slotNumber << '\n';
        cout << "Arrival Time         : "
             << ctime(&vehicle->arrivalTime);
        cout << "Exit Time            : "
             << ctime(&exitTime);
        cout << "Total Time           : "
             << hours << " hour(s) " << minutes << " minute(s)\n";
        cout << fixed << setprecision(2);
        cout << "Parking Fee          : Ksh " << fee << '\n';
        cout << "-----------------------------------------\n";

        double payment;
        cout << "Enter amount paid: Ksh ";
        cin >> payment;

        if (payment < fee) {
            cout << "\nInsufficient payment.\n";
            cout << "Vehicle cannot exit until full payment is made.\n";
            return;
        }

        double change = payment - fee;
        cout << "Change               : Ksh " << change << '\n';
        cout << "\nPayment successful!\n";

        // Release the parking slot.
        int slotIndex = vehicle->slotNumber - 1;
        parkingSlots[slotIndex].occupied = false;
        parkingSlots[slotIndex].vehicleRegistration = "";

        // Remove the completed parking session from active records.
        parkedVehicles.erase(vehicle);

        cout << "\n=========================================\n";
        cout << "       PAYMENT SUCCESSFUL\n";
        cout << "       BARRIER: OPEN\n";
        cout << "       THANK YOU!\n";
        cout << "=========================================\n";
    }

    // Display all vehicles currently inside the parking area.
    void displayParkedVehicles() const {
        cout << "\n=========================================\n";
        cout << "          PARKED VEHICLES\n";
        cout << "=========================================\n";

        if (parkedVehicles.empty()) {
            cout << "There are currently no parked vehicles.\n";
            return;
        }

        for (const auto& vehicle : parkedVehicles) {
            cout << "Registration : " << vehicle.registrationNumber << '\n';
            cout << "Slot         : " << vehicle.slotNumber << '\n';
            cout << "Arrival      : " << ctime(&vehicle.arrivalTime);
            cout << "-----------------------------------------\n";
        }
    }
};

int main() {
    // Create a parking area with 10 slots.
    ParkingSystem parking(10);

    int choice;

    do {
        cout << "\n\n";
        cout << "============================================\n";
        cout << "       MODERN PARKING SYSTEM - KENYA\n";
        cout << "============================================\n";
        cout << "1. View Parking Slot Availability\n";
        cout << "2. Vehicle Arrival\n";
        cout << "3. Vehicle Exit\n";
        cout << "4. View Parked Vehicles\n";
        cout << "5. Exit System\n";
        cout << "============================================\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                parking.displayParkingSlots();
                break;
            case 2:
                parking.vehicleArrival();
                break;
            case 3:
                parking.vehicleExit();
                break;
            case 4:
                parking.displayParkedVehicles();
                break;
            case 5:
                cout << "\nThank you for using the Modern Parking System.\n";
                break;
            default:
                cout << "\nInvalid choice. Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
